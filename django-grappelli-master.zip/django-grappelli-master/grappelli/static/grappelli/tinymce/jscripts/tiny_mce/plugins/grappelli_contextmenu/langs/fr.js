tinyMCE.addI18n("fr.grappelli_contextmenu",{
grappelli_contextmenu_insertpbefore_desc:"Insérer Paragraph AVANT la sélection",
grappelli_contextmenu_insertpafter_desc:"Insérer Paragraph APRÈS la sélection",
grappelli_contextmenu_insertpbeforeroot_desc:"Insérer Paragraph AVANT la racine de la sélection",
grappelli_contextmenu_insertpafterroot_desc:"Insérer Paragraph APRÈS la racine de la sélection",
grappelli_contextmenu_delete_desc:"Supprimer la sélection",
grappelli_contextmenu_deleteroot_desc:"Supprimer la racine de la sélection",
grappelli_contextmenu_moveup_desc:"Monter la sélection",
grappelli_contextmenu_moveuproot_desc:"Monter la racine de la sélection",
});
