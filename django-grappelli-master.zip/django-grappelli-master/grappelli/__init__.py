VERSION = '2.13.1'
default_app_config = 'grappelli.apps.GrappelliConfig'
