from grappelli.dashboard.dashboards import *
from grappelli.dashboard.registry import *

default_app_config = "grappelli.dashboard.apps.DashboardConfig"
