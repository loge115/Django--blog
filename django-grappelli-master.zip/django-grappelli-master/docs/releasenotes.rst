:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _releasenotes:

Grappelli 2.13.x Release Notes
==============================

**Grappelli 2.13.x is compatible with Django 2.2**.

Update from Grappelli 2.12.x
----------------------------

* Update Django to 2.2 and check https://docs.djangoproject.com/en/dev/releases/2.2/
* Update Grappelli to 2.13.x
