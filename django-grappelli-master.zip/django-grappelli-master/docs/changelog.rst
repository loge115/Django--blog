:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _changelog:

Changelog
=========

2.13.2 (not yet released)
-------------------------

2.13.1 (June 25th 2019)
-----------------------

* First release of Grappelli which is compatible with Django 2.2.
